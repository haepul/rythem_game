import pygame
import time
import random
import sys
import math
import os
import asyncio  # 상단에 추가
import os
import pygame
# ---------------------------------------------------------
# 1. 초기 설정 및 폰트
# ---------------------------------------------------------
pygame.init()
pygame.font.init()

SCREEN_WIDTH, SCREEN_HEIGHT = 800, 480
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Touch Rhythm Game - SEKAI Style Final")
clock = pygame.time.Clock()

def load_korean_font(size, bold=False):
    # 폴더에 넣어둔 DNFBitBitv2.ttf 파일을 직접 불러옵니다.
    return pygame.font.Font("DNFBitBitv2.ttf", size)

# 폰트 사이즈 전체적으로 축소 (UI 잘림 방지)
font_combo_num = load_korean_font(50, bold=True)
font_combo_sub = load_korean_font(16, bold=True)
font_large = load_korean_font(28, bold=True)
font_med = load_korean_font(18, bold=True)
font_small = load_korean_font(13, bold=True)

# ---------------------------------------------------------
# 2. 3D 퍼스펙티브(원근감) 트랙 설정
# ---------------------------------------------------------
TRACK_TOP_Y = 110        
TRACK_BOTTOM_Y = 410     
JUDGE_Y = TRACK_BOTTOM_Y

TRACK_TOP_W = 220       
TRACK_BOTTOM_W = 640    
CENTER_X = SCREEN_WIDTH // 2

def get_perspective_pos(lane, progress):
    p_clamped = max(0.0, progress)
    p_curved = math.pow(p_clamped, 1.55)
    y = TRACK_TOP_Y + (TRACK_BOTTOM_Y - TRACK_TOP_Y) * p_curved
    current_track_w = TRACK_TOP_W + (TRACK_BOTTOM_W - TRACK_TOP_W) * p_curved
    lane_w = current_track_w / 4.0
    track_left = CENTER_X - (current_track_w / 2.0)
    x_center = track_left + (lane + 0.5) * lane_w
    return x_center, y, lane_w

def generate_bg_surface(colors, accent):
    surf = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
    c_top, c_mid, c_bot = colors
    for y in range(SCREEN_HEIGHT):
        ratio = y / SCREEN_HEIGHT
        if ratio < 0.5:
            r1 = ratio * 2
            r = int(c_top[0] * (1 - r1) + c_mid[0] * r1)
            g = int(c_top[1] * (1 - r1) + c_mid[1] * r1)
            b = int(c_top[2] * (1 - r1) + c_mid[2] * r1)
        else:
            r2 = (ratio - 0.5) * 2
            r = int(c_mid[0] * (1 - r2) + c_bot[0] * r2)
            g = int(c_mid[1] * (1 - r2) + c_bot[2] * r2)
            b = int(c_mid[2] * (1 - r2) + c_bot[2] * r2)
        pygame.draw.line(surf, (r, g, b), (0, y), (SCREEN_WIDTH, y))
        
    for _ in range(20):
        rx = random.randint(0, SCREEN_WIDTH)
        ry = random.randint(0, SCREEN_HEIGHT)
        pygame.draw.circle(surf, accent, (rx, ry), random.randint(1, 2))
    return surf

default_bg_surface = generate_bg_surface(((18, 10, 40), (10, 20, 50), (5, 5, 15)), (0, 180, 255))
current_bg_surface = default_bg_surface

# ---------------------------------------------------------
# 3. 유틸리티 & 그래디언트 렌더러
# ---------------------------------------------------------
def interpolate_color(c1, c2, t):
    t = max(0.0, min(1.0, t))
    return (
        int(c1[0] + (c2[0] - c1[0]) * t),
        int(c1[1] + (c2[1] - c1[1]) * t),
        int(c1[2] + (c2[2] - c1[2]) * t)
    )

def draw_styled_text(surface, text, font, center_x, center_y, text_color, shadow_color=(0, 0, 0), scale=1.0):
    base_img = font.render(text, True, text_color)
    shadow_img = font.render(text, True, shadow_color)
    if scale != 1.0:
        w = max(1, int(base_img.get_width() * scale))
        h = max(1, int(base_img.get_height() * scale))
        base_img = pygame.transform.smoothscale(base_img, (w, h))
        shadow_img = pygame.transform.smoothscale(shadow_img, (w, h))
    rect = base_img.get_rect(center=(center_x, center_y))
    shadow_rect = shadow_img.get_rect(center=(center_x + 2, center_y + 2))
    surface.blit(shadow_img, shadow_rect)
    surface.blit(base_img, rect)

def draw_gradient_note(surface, lane, p_top, p_bot, color_top, color_bot, width_scale=0.48, steps=6):
    p_top_c = max(0.0, min(1.15, p_top))
    p_bot_c = max(0.0, min(1.15, p_bot))
    if p_top_c >= p_bot_c: return
    for i in range(steps):
        t1, t2 = i / steps, (i + 1) / steps
        curr_p1 = p_top_c + (p_bot_c - p_top_c) * t1
        curr_p2 = p_top_c + (p_bot_c - p_top_c) * t2
        x1, y1, w1 = get_perspective_pos(lane, curr_p1)
        x2, y2, w2 = get_perspective_pos(lane, curr_p2)
        col = interpolate_color(color_top, color_bot, t1)
        poly = [
            (x1 - w1 * width_scale, y1), (x1 + w1 * width_scale, y1),
            (x2 + w2 * width_scale, y2), (x2 - w2 * width_scale, y2)
        ]
        pygame.draw.polygon(surface, col, poly)
    
    x_top, y_top, w_top = get_perspective_pos(lane, p_top_c)
    x_bot, y_bot, w_bot = get_perspective_pos(lane, p_bot_c)
    full_poly = [
        (x_top - w_top * width_scale, y_top), (x_top + w_top * width_scale, y_top),
        (x_bot + w_bot * width_scale, y_bot), (x_bot - w_bot * width_scale, y_bot)
    ]
    pygame.draw.polygon(surface, (255, 255, 255), full_poly, 2)
    pygame.draw.line(surface, (255, 255, 255), (x_top - w_top * width_scale, y_top), (x_top + w_top * width_scale, y_top), 3)

# ---------------------------------------------------------
# 4. 곡 데이터 (난이도 이름 적용) 및 로컬 기록 저장소
# ---------------------------------------------------------
MAP_LIST = [
    {"title": "입문 (Beginner)", "level": 1, "duration": 30, "colors": ((15, 35, 25), (10, 50, 40), (5, 20, 15)), "accent": (100, 255, 180)},
    {"title": "매우 쉬움 (Very Easy)", "level": 2, "duration": 35, "colors": ((25, 20, 40), (40, 30, 60), (10, 10, 25)), "accent": (180, 150, 255)},
    {"title": "쉬움 (Easy)", "level": 3, "duration": 40, "colors": ((50, 15, 25), (60, 25, 20), (20, 5, 10)), "accent": (255, 120, 80)},
    {"title": "보통 (Normal)", "level": 4, "duration": 40, "colors": ((10, 15, 35), (15, 25, 55), (5, 5, 15)), "accent": (80, 160, 255)},
    {"title": "약간 어려움 (Hard)", "level": 5, "duration": 45, "colors": ((35, 10, 40), (50, 10, 60), (15, 5, 20)), "accent": (255, 50, 200)},
    {"title": "어려움 (Expert)", "level": 6, "duration": 45, "colors": ((10, 25, 40), (15, 40, 60), (5, 15, 25)), "accent": (100, 200, 255)},
    {"title": "매우 어려움 (Expert+)", "level": 7, "duration": 50, "colors": ((30, 30, 10), (50, 50, 15), (15, 15, 5)), "accent": (255, 230, 50)},
    {"title": "마스터 (Master)", "level": 8, "duration": 50, "colors": ((45, 25, 10), (60, 35, 15), (20, 10, 5)), "accent": (255, 160, 50)},
    {"title": "지옥 (Hell)", "level": 9, "duration": 55, "colors": ((10, 40, 45), (15, 60, 65), (5, 20, 25)), "accent": (0, 255, 220)},
    {"title": "끝판왕 (Chaos)", "level": 10, "duration": 60, "colors": ((45, 10, 10), (65, 15, 15), (20, 5, 5)), "accent": (255, 60, 60)},
]

# 성취도를 위한 로컬 기록 딕셔너리
player_records = {i: {"grade": "-", "fc": False} for i in range(len(MAP_LIST))}

def generate_chart(level, duration):
    notes = []
    current_time = 2.0
    while current_time < duration:
        lane = random.randint(0, 3)
        note_type = random.choices(["TAP", "HOLD", "SLIDE"], weights=[10 - level*0.5, level*0.3, level*0.2])[0]
        if note_type == "TAP":
            notes.append({"type": "TAP", "time": current_time, "lane": lane, "hit": False})
            current_time += max(0.18, 0.9 - (level * 0.07))
        elif note_type == "HOLD":
            hold_len = random.uniform(0.3, 0.65)
            notes.append({"type": "HOLD", "time": current_time, "end_time": current_time + hold_len, "lane": lane, "hit": False, "active": False})
            current_time += hold_len + max(0.18, 0.6 - (level * 0.04))
        elif note_type == "SLIDE":
            end_lane = random.choice([l for l in range(4) if l != lane])
            slide_len = random.uniform(0.35, 0.7)
            notes.append({"type": "SLIDE", "time": current_time, "end_time": current_time + slide_len, "lane": lane, "end_lane": end_lane, "hit": False, "active": False})
            current_time += slide_len + max(0.18, 0.6 - (level * 0.04))
    return notes

# ---------------------------------------------------------
# 5. 게임 상태 & 변수
# ---------------------------------------------------------
state = "HOME"
current_map, current_map_idx = None, -1
chart = []
score = 0
combo, max_combo, total_notes, hit_score = 0, 0, 0, 0
hp = 100.0 
particles = []


# ---------------------------------------------------------
# 5. 게임 상태 & 변수
# ---------------------------------------------------------
state = "HOME"
current_map, current_map_idx = None, -1
chart = []
score = 0
combo, max_combo, total_notes, hit_score = 0, 0, 0, 0
hp = 100.0 
particles = []

# 판정 횟수 카운터
perfect_count, great_count, miss_count = 0, 0, 0

APPROACH_TIME = 1.2
PERFECT_TIME = 0.07
GREAT_TIME = 0.15

active_touches = {}
combo_scale = 1.0
feedback_scale = 1.0
last_feedback = ""
last_feedback_color = (255, 255, 255)
feedback_time = 0
pause_start_time = 0

def get_grade(accuracy):
    if accuracy >= 95: return "S", (255, 215, 0)
    if accuracy >= 85: return "A", (0, 255, 120)
    if accuracy >= 75: return "B", (0, 200, 255)
    if accuracy >= 60: return "C", (255, 160, 0)
    return "F", (255, 60, 60)

def spawn_particles(x, y, color, count=16, power=1.0):
    for _ in range(count):
        vx = random.uniform(-8 * power, 8 * power)
        vy = random.uniform(-10 * power, -2 * power)
        size = random.uniform(3, 9)
        particles.append([x, y, vx, vy, size, color])

def format_time(seconds):
    secs = max(0, int(seconds))
    return f"{secs // 60:02d}:{secs % 60:02d}"

def start_game(m_idx):
    global current_map, current_map_idx, chart, total_notes, score, combo, max_combo, hit_score, hp
    global perfect_count, great_count, miss_count, game_start_time, current_bg_surface, state
    
    current_map_idx = m_idx
    current_map = MAP_LIST[m_idx]
    chart = generate_chart(current_map["level"], current_map["duration"])
    total_notes = len(chart)
    score, combo, max_combo, hit_score = 0, 0, 0, 0
    perfect_count, great_count, miss_count = 0, 0, 0
    hp = 100.0
    particles.clear()
    current_bg_surface = generate_bg_surface(current_map["colors"], current_map["accent"])
    game_start_time = time.time()
    state = "PLAY"
    active_touches.clear()

# ---------------------------------------------------------
# 6. 비동기 메인 루프 (Web/pygbag 전용)
# ---------------------------------------------------------
async def main():
    global state, current_map, current_map_idx, chart, score, combo, max_combo, total_notes, hit_score, hp, particles
    global perfect_count, great_count, miss_count, active_touches, combo_scale, feedback_scale
    global last_feedback, last_feedback_color, feedback_time, pause_start_time, game_start_time, current_bg_surface

    running = True
    game_start_time = 0
    btn_pause = pygame.Rect(740, 15, 45, 35)

    while running:
        dt = clock.tick(60) / 1000.0
        mouse_click = False
        mouse_pos = pygame.mouse.get_pos()
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE and state in ["PLAY", "PAUSED"]:
                    if state == "PLAY":
                        state = "PAUSED"
                        pause_start_time = time.time()
                    elif state == "PAUSED":
                        state = "PLAY"
                        game_start_time += (time.time() - pause_start_time)
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mouse_click = True
                active_touches[event.button] = event.pos[0]
            elif event.type == pygame.MOUSEMOTION:
                if event.buttons[0]:
                    active_touches[1] = event.pos[0]
            elif event.type == pygame.MOUSEBUTTONUP:
                if event.button in active_touches:
                    del active_touches[event.button]

        pressed_lanes = []
        track_b_left = CENTER_X - (TRACK_BOTTOM_W / 2)
        lane_w_bottom = TRACK_BOTTOM_W / 4.0
        
        if state == "PLAY":
            for touch_x in active_touches.values():
                if track_b_left <= touch_x <= track_b_left + TRACK_BOTTOM_W:
                    lane_idx = int((touch_x - track_b_left) // lane_w_bottom)
                    pressed_lanes.append(min(3, max(0, lane_idx)))

        combo_scale = max(1.0, combo_scale - dt * 2.5)
        feedback_scale = max(1.0, feedback_scale - dt * 3.0)

        # ==========================================
        # SCENE: HOME
        # ==========================================
        if state == "HOME":
            screen.blit(default_bg_surface, (0, 0))
            draw_styled_text(screen, "곡 선택 (SELECT TRACK)", font_large, CENTER_X, 45, (255, 255, 255))
            
            for i, m in enumerate(MAP_LIST):
                col, row = i % 5, i // 5
                rect = pygame.Rect(30 + col*150, 100 + row*150, 140, 120)
                
                pygame.draw.rect(screen, (25, 30, 55), rect, border_radius=12)
                pygame.draw.rect(screen, m["accent"], rect, width=2, border_radius=12)
                
                if mouse_click and rect.collidepoint(mouse_pos):
                    start_game(i)
                
                lvl = font_small.render(f"LV. {m['level']}", True, m["accent"])
                t_name = font_small.render(m['title'], True, (255, 255, 255))
                screen.blit(lvl, (rect.x + 12, rect.y + 15))
                
                t_rect = t_name.get_rect(center=(rect.centerx, rect.y + 60))
                screen.blit(t_name, t_rect)

                record = player_records[i]
                if record["grade"] != "-":
                    _, g_color = get_grade(100 if record["grade"] == "S" else (85 if record["grade"] == "A" else 75))
                    draw_styled_text(screen, record["grade"], font_med, rect.right - 20, rect.top + 20, g_color)
                    if record["fc"]:
                        pygame.draw.rect(screen, (255, 200, 0), (rect.right - 35, rect.top + 35, 30, 15), border_radius=4)
                        fc_text = font_small.render("FC", True, (0, 0, 0))
                        screen.blit(fc_text, (rect.right - 32, rect.top + 35))

        # ==========================================
        # SCENE: PLAY
        # ==========================================
        elif state == "PLAY":
            play_time = time.time() - game_start_time
            screen.blit(current_bg_surface, (0, 0))
            
            top_l, top_r = CENTER_X - TRACK_TOP_W / 2, CENTER_X + TRACK_TOP_W / 2
            bot_l, bot_r = CENTER_X - TRACK_BOTTOM_W / 2, CENTER_X + TRACK_BOTTOM_W / 2
            
            pygame.draw.polygon(screen, (12, 15, 28), [(top_l, TRACK_TOP_Y), (top_r, TRACK_TOP_Y), (bot_r, TRACK_BOTTOM_Y), (bot_l, TRACK_BOTTOM_Y)])
            
            for lane in set(pressed_lanes):
                x1_l, y1, _ = get_perspective_pos(lane - 0.5, 0.0)
                x1_r, y1, _ = get_perspective_pos(lane + 0.5, 0.0)
                x2_l, y2, _ = get_perspective_pos(lane - 0.5, 1.0)
                x2_r, y2, _ = get_perspective_pos(lane + 0.5, 1.0)
                pygame.draw.polygon(screen, current_map["accent"], [(x1_l, y1), (x1_r, y1), (x2_r, y2), (x2_l, y2)])

            for i in range(5):
                lane_ratio = i / 4.0
                x_top, x_bot = top_l + TRACK_TOP_W * lane_ratio, bot_l + TRACK_BOTTOM_W * lane_ratio
                pygame.draw.line(screen, (50, 80, 140), (x_top, TRACK_TOP_Y), (x_bot, TRACK_BOTTOM_Y), 2)

            pygame.draw.line(screen, (0, 240, 255), (bot_l - 12, JUDGE_Y), (bot_r + 12, JUDGE_Y), 8)
            pygame.draw.line(screen, (255, 255, 255), (bot_l - 10, JUDGE_Y), (bot_r + 10, JUDGE_Y), 2)

            for lane in range(4):
                cx, cy, cw = get_perspective_pos(lane, 1.0)
                pad_w, pad_h = cw * 0.44, 14
                pad_poly = [
                    (cx - pad_w, cy - pad_h//2), (cx + pad_w, cy - pad_h//2),
                    (cx + pad_w*1.08, cy + pad_h//2), (cx - pad_w*1.08, cy + pad_h//2)
                ]
                if lane in pressed_lanes:
                    pygame.draw.polygon(screen, (0, 255, 240), pad_poly)
                    pygame.draw.polygon(screen, (255, 255, 255), pad_poly, 2)
                else:
                    pygame.draw.polygon(screen, (20, 35, 65), pad_poly)
                    pygame.draw.polygon(screen, (0, 200, 255), pad_poly, 2)

            TAP_TOP, TAP_BOT = (180, 255, 255), (0, 150, 255)
            HOLD_TOP, HOLD_BOT = (255, 255, 150), (0, 220, 180)
            SLIDE_TOP, SLIDE_BOT = (255, 150, 255), (180, 0, 230)

            for note in chart[:]:
                if note["hit"]: continue
                
                time_diff = note["time"] - play_time
                progress = 1.0 - (time_diff / APPROACH_TIME)
                
                if note["type"] == "TAP":
                    if -0.2 <= progress <= 1.2:
                        draw_gradient_note(screen, note["lane"], progress - 0.065, progress + 0.065, TAP_TOP, TAP_BOT)
                    
                    if note["lane"] in pressed_lanes and mouse_click:
                        abs_diff = abs(time_diff)
                        if abs_diff <= GREAT_TIME:
                            note["hit"] = True
                            combo += 1
                            combo_scale, feedback_scale = 1.35, 1.4
                            hit_x, hit_y, _ = get_perspective_pos(note["lane"], 1.0)
                            spawn_particles(hit_x, hit_y, TAP_TOP, count=16)
                            
                            if abs_diff <= PERFECT_TIME:
                                score += 200 + (combo * 10)
                                hit_score += 100
                                perfect_count += 1
                                hp = min(100.0, hp + 2.0)
                                last_feedback, last_feedback_color = "PERFECT", (255, 215, 0)
                            else:
                                score += 100 + (combo * 5)
                                hit_score += 70
                                great_count += 1
                                hp = min(100.0, hp + 1.0)
                                last_feedback, last_feedback_color = "GREAT", (0, 255, 255)
                            feedback_time = time.time()
                    
                    if time_diff < -GREAT_TIME:
                        note["hit"] = True
                        combo = 0
                        miss_count += 1
                        hp -= 18.0 
                        last_feedback, last_feedback_color = "MISS", (255, 60, 60)
                        feedback_scale, feedback_time = 1.2, time.time()

                elif note["type"] == "HOLD":
                    p_head = 1.0 if note["active"] else progress
                    p_tail = 1.0 - ((note["end_time"] - play_time) / APPROACH_TIME)
                    
                    if p_head >= 0.0 and p_tail <= 1.15:
                        draw_gradient_note(screen, note["lane"], max(0.0, min(1.15, p_tail)), max(0.0, min(1.15, p_head)), HOLD_TOP, HOLD_BOT, steps=8)
                    
                    if note["lane"] in pressed_lanes:
                        if abs(time_diff) <= GREAT_TIME and not note["active"]:
                            note["active"] = True
                            hit_x, hit_y, _ = get_perspective_pos(note["lane"], 1.0)
                            spawn_particles(hit_x, hit_y, HOLD_TOP, count=10)
                        if note["active"]:
                            hit_x, hit_y, _ = get_perspective_pos(note["lane"], 1.0)
                            spawn_particles(hit_x, hit_y, HOLD_TOP, count=3)
                    else:
                        if note["active"] and play_time < note["end_time"] - 0.15:
                            note["hit"] = True
                            combo = 0
                            miss_count += 1
                            hp -= 18.0
                            last_feedback, last_feedback_color = "MISS", (255, 60, 60)
                            feedback_time = time.time()

                    if note["active"] and play_time >= note["end_time"]:
                        note["hit"] = True
                        score += 300 + (combo * 10)
                        hit_score += 100
                        perfect_count += 1
                        hp = min(100.0, hp + 3.0)
                        combo += 1
                        combo_scale, feedback_scale = 1.35, 1.4
                        last_feedback, last_feedback_color = "PERFECT", (255, 215, 0)
                        feedback_time = time.time()
                        hit_x, hit_y, _ = get_perspective_pos(note["lane"], 1.0)
                        spawn_particles(hit_x, hit_y, (255, 255, 255), count=25, power=1.4)
                        
                    if time_diff < -GREAT_TIME and not note["active"]:
                        note["hit"] = True
                        combo = 0
                        miss_count += 1
                        hp -= 18.0

                elif note["type"] == "SLIDE":
                    t_head = play_time if note["active"] else note["time"]
                    t_tail = note["end_time"]
                    t_vis_min = max(t_head, play_time - 0.05 * APPROACH_TIME)
                    t_vis_max = min(t_tail, play_time + APPROACH_TIME)
                    
                    if t_vis_min < t_vis_max:
                        steps = 10
                        pts_l, pts_r = [], []
                        for s in range(steps + 1):
                            t_curr = t_vis_min + (t_vis_max - t_vis_min) * (s / steps)
                            slide_ratio = (t_curr - note["time"]) / (note["end_time"] - note["time"])
                            curr_lane = note["lane"] + (note["end_lane"] - note["lane"]) * slide_ratio
                            
                            if note["active"]:
                                p_ratio = (t_curr - play_time) / (note["end_time"] - play_time) if note["end_time"] > play_time else 0
                                curr_p = 1.0 - p_ratio * (1.0 - (1.0 - ((note["end_time"] - play_time) / APPROACH_TIME)))
                            else:
                                curr_p = 1.0 - ((t_curr - play_time) / APPROACH_TIME)
                            
                            xc, yc, wc = get_perspective_pos(curr_lane, curr_p)
                            pts_l.append((xc - wc * 0.46, yc))
                            pts_r.append((xc + wc * 0.46, yc))
                        pygame.draw.polygon(screen, SLIDE_BOT, pts_l + pts_r[::-1])
                        pygame.draw.polygon(screen, (255, 255, 255), pts_l + pts_r[::-1], 2)

                    if note["time"] <= play_time <= note["end_time"]:
                        cur_ratio = (play_time - note["time"]) / (note["end_time"] - note["time"])
                        active_cur_lane = note["lane"] + (note["end_lane"] - note["lane"]) * cur_ratio
                    else:
                        active_cur_lane = note["lane"]

                    if int(active_cur_lane) in pressed_lanes or math.ceil(active_cur_lane) in pressed_lanes or int(round(active_cur_lane)) in pressed_lanes:
                        if abs(time_diff) <= GREAT_TIME and not note["active"]:
                            note["active"] = True
                        if note["active"]:
                            hit_x, hit_y, _ = get_perspective_pos(active_cur_lane, 1.0)
                            spawn_particles(hit_x, hit_y, SLIDE_TOP, count=4)

                    if note["active"] and play_time >= note["end_time"]:
                        note["hit"] = True
                        score += 400 + (combo * 10)
                        hit_score += 100
                        perfect_count += 1
                        hp = min(100.0, hp + 4.0)
                        combo += 1
                        combo_scale, feedback_scale = 1.35, 1.4
                        last_feedback, last_feedback_color = "PERFECT", (255, 215, 0)
                        feedback_time = time.time()
                        hit_x, hit_y, _ = get_perspective_pos(note["end_lane"], 1.0)
                        spawn_particles(hit_x, hit_y, (255, 255, 255), count=25, power=1.5)

                    if time_diff < -GREAT_TIME and not note["active"]:
                        note["hit"] = True
                        combo = 0
                        miss_count += 1
                        hp -= 18.0

            if hp <= 0:
                state = "GAME_OVER"

            for p in particles[:]:
                p[0] += p[2]; p[1] += p[3]; p[3] += 0.45; p[4] -= 0.14
                if p[4] > 0: pygame.draw.circle(screen, p[5], (int(p[0]), int(p[1])), int(p[4]))
                else: particles.remove(p)

            max_combo = max(max_combo, combo)
            draw_styled_text(screen, f"점수: {score:,}", font_med, 90, 20, (255, 255, 255))
            
            draw_styled_text(screen, "HP", font_small, 30, 48, (255, 255, 255))
            pygame.draw.rect(screen, (40, 20, 20), (45, 42, 110, 12), border_radius=4)
            hp_ratio = max(0.0, hp / 100.0)
            hp_color = (0, 255, 120) if hp > 50 else (255, 200, 0) if hp > 25 else (255, 50, 50)
            pygame.draw.rect(screen, hp_color, (45, 42, int(110 * hp_ratio), 12), border_radius=4)
            pygame.draw.rect(screen, (255, 255, 255), (45, 42, 110, 12), width=1, border_radius=4)

            prog_ratio = min(1.0, max(0.0, play_time / current_map["duration"]))
            bar_w, bar_h = 240, 8
            bar_x, bar_y = CENTER_X - bar_w // 2, 35
            time_str = f"{format_time(play_time)} / {format_time(current_map['duration'])}"
            title_str = f"{current_map['title']} (LV.{current_map['level']})"
            
            draw_styled_text(screen, title_str, font_small, CENTER_X, 15, (200, 240, 255))
            pygame.draw.rect(screen, (20, 25, 45), (bar_x, bar_y, bar_w, bar_h), border_radius=4)
            if prog_ratio > 0:
                pygame.draw.rect(screen, (0, 230, 255), (bar_x, bar_y, int(bar_w * prog_ratio), bar_h), border_radius=4)
            pygame.draw.rect(screen, (255, 255, 255), (bar_x, bar_y, bar_w, bar_h), width=1, border_radius=4)
            draw_styled_text(screen, time_str, font_small, CENTER_X + 165, 38, (200, 200, 200))

            pygame.draw.rect(screen, (30, 40, 70), btn_pause, border_radius=8)
            pygame.draw.rect(screen, (0, 220, 255), btn_pause, width=2, border_radius=8)
            pygame.draw.rect(screen, (255, 255, 255), (btn_pause.x + 14, btn_pause.y + 9, 5, 17))
            pygame.draw.rect(screen, (255, 255, 255), (btn_pause.x + 26, btn_pause.y + 9, 5, 17))

            if mouse_click and btn_pause.collidepoint(mouse_pos):
                state = "PAUSED"
                pause_start_time = time.time()

            if combo >= 3:
                draw_styled_text(screen, f"{combo}", font_combo_num, CENTER_X, 150, (255, 220, 0), scale=combo_scale)
                draw_styled_text(screen, "COMBO", font_combo_sub, CENTER_X, 190, (255, 255, 255))

            if time.time() - feedback_time < 0.45:
                draw_styled_text(screen, last_feedback, font_large, CENTER_X, 270, last_feedback_color, scale=feedback_scale)

            if play_time > current_map["duration"] + 1.5:
                accuracy = (hit_score / (total_notes * 100)) * 100 if total_notes > 0 else 0
                grade_str, _ = get_grade(accuracy)
                
                prev = player_records[current_map_idx]["grade"]
                ranks = ["S", "A", "B", "C", "F", "-"]
                if ranks.index(grade_str) < ranks.index(prev):
                    player_records[current_map_idx]["grade"] = grade_str
                    
                if miss_count == 0:
                    player_records[current_map_idx]["fc"] = True
                    
                state = "RESULT"

        # ==========================================
        # SCENE: PAUSED
        # ==========================================
        elif state == "PAUSED":
            dim_surf = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
            dim_surf.set_alpha(150)
            dim_surf.fill((0, 0, 0))
            screen.blit(dim_surf, (0, 0))
            
            box = pygame.Rect(CENTER_X - 140, 110, 280, 250)
            pygame.draw.rect(screen, (20, 25, 45), box, border_radius=16)
            pygame.draw.rect(screen, (0, 200, 255), box, width=2, border_radius=16)
            
            draw_styled_text(screen, "PAUSED", font_large, CENTER_X, 150, (255, 255, 255))
            
            btn_resume, btn_retry, btn_home = pygame.Rect(CENTER_X - 100, 200, 200, 40), pygame.Rect(CENTER_X - 100, 250, 200, 40), pygame.Rect(CENTER_X - 100, 300, 200, 40)
            
            pygame.draw.rect(screen, (0, 180, 220), btn_resume, border_radius=8)
            pygame.draw.rect(screen, (100, 100, 150), btn_retry, border_radius=8)
            pygame.draw.rect(screen, (220, 60, 80), btn_home, border_radius=8)
            
            draw_styled_text(screen, "계속하기", font_med, CENTER_X, 220, (255, 255, 255))
            draw_styled_text(screen, "다시하기", font_med, CENTER_X, 270, (255, 255, 255))
            draw_styled_text(screen, "메뉴로", font_med, CENTER_X, 320, (255, 255, 255))
            
            if mouse_click:
                if btn_resume.collidepoint(mouse_pos):
                    state = "PLAY"
                    game_start_time += (time.time() - pause_start_time)
                elif btn_retry.collidepoint(mouse_pos):
                    start_game(current_map_idx)
                elif btn_home.collidepoint(mouse_pos):
                    state = "HOME"

        # ==========================================
        # SCENE: GAME OVER
        # ==========================================
        elif state == "GAME_OVER":
            screen.blit(current_bg_surface, (0, 0))
            dim_surf = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
            dim_surf.set_alpha(200)
            dim_surf.fill((20, 0, 0))
            screen.blit(dim_surf, (0, 0))
            
            draw_styled_text(screen, "GAME OVER", font_large, CENTER_X, 120, (255, 50, 50))
            draw_styled_text(screen, "체력이 모두 소진되었습니다!", font_med, CENTER_X, 180, (220, 220, 220))
            draw_styled_text(screen, f"진행 점수: {score:,}", font_med, CENTER_X, 230, (255, 255, 255))
            
            btn_retry, btn_home = pygame.Rect(CENTER_X - 160, 310, 140, 50), pygame.Rect(CENTER_X + 20, 310, 140, 50)
            
            pygame.draw.rect(screen, (0, 180, 220), btn_retry, border_radius=10)
            pygame.draw.rect(screen, (220, 60, 80), btn_home, border_radius=10)
            
            draw_styled_text(screen, "다시하기", font_med, btn_retry.centerx, btn_retry.centery, (255, 255, 255))
            draw_styled_text(screen, "메뉴로", font_med, btn_home.centerx, btn_home.centery, (255, 255, 255))
            
            if mouse_click:
                if btn_retry.collidepoint(mouse_pos): start_game(current_map_idx)
                elif btn_home.collidepoint(mouse_pos): state = "HOME"

        # ==========================================
        # SCENE: RESULT
        # ==========================================
        elif state == "RESULT":
            screen.blit(current_bg_surface, (0, 0))
            accuracy = (hit_score / (total_notes * 100)) * 100 if total_notes > 0 else 0
            grade_str, grade_color = get_grade(accuracy)
            
            draw_styled_text(screen, "STAGE CLEAR!", font_large, CENTER_X, 60, (255, 255, 255))
            
            if miss_count == 0:
                if perfect_count == total_notes:
                    draw_styled_text(screen, "ALL PERFECT!!", font_large, CENTER_X, 105, (255, 255, 255), (0, 200, 255))
                else:
                    draw_styled_text(screen, "FULL COMBO!", font_large, CENTER_X, 105, (255, 215, 0), (255, 100, 0))
            
            draw_styled_text(screen, f"GRADE: {grade_str}", font_large, CENTER_X, 150, grade_color)
            draw_styled_text(screen, f"최종 점수: {score:,}", font_med, CENTER_X, 200, (220, 220, 220))
            
            draw_styled_text(screen, f"PERFECT : {perfect_count}", font_med, CENTER_X - 100, 240, (255, 215, 0))
            draw_styled_text(screen, f"GREAT : {great_count}", font_med, CENTER_X - 100, 270, (0, 255, 255))
            draw_styled_text(screen, f"MISS : {miss_count}", font_med, CENTER_X - 100, 300, (255, 60, 60))
            
            draw_styled_text(screen, f"최대 콤보: {max_combo}", font_med, CENTER_X + 100, 255, (220, 220, 220))
            draw_styled_text(screen, f"정확도: {accuracy:.1f}%", font_med, CENTER_X + 100, 285, (220, 220, 220))
            
            btn_home = pygame.Rect(CENTER_X - 170, 370, 150, 55)
            btn_retry = pygame.Rect(CENTER_X + 20, 370, 150, 55)
            
            pygame.draw.rect(screen, (0, 180, 220), btn_home, border_radius=12)
            pygame.draw.rect(screen, (255, 0, 100), btn_retry, border_radius=12)
            
            draw_styled_text(screen, "메뉴로", font_med, btn_home.centerx, btn_home.centery, (255, 255, 255))
            draw_styled_text(screen, "다시하기", font_med, btn_retry.centerx, btn_retry.centery, (255, 255, 255))
            
            if mouse_click:
                if btn_home.collidepoint(mouse_pos):
                    state = "HOME"
                elif btn_retry.collidepoint(mouse_pos):
                    start_game(current_map_idx)

        pygame.display.flip()
        
        # [핵심] 웹 브라우저 상의 비동기 양보
        await asyncio.sleep(0)

    pygame.quit()
    sys.exit()

# 프로그램 실행 포인트
asyncio.run(main())